import matplotlib.pyplot as plt

# 原始数据
respo = {"1":{"id":1,"position":{"x":15.887383328317865,"y":-21.75384488363798},"digits":[7],"last_update":572.218,"in_region":True},"2":{"id":2,"position":{"x":15.790508803014426,"y":-17.928985234441463},"digits":[9],"last_update":575.319,"in_region":True},"3":{"id":3,"position":{"x":16.414713847096394,"y":-17.552427501796167},"digits":[8],"last_update":574.469,"in_region":True},"4":{"id":4,"position":{"x":18.800842932526287,"y":-18.82168375092396},"digits":[8],"last_update":577.218,"in_region":True},"5":{"id":5,"position":{"x":12.649369649099848,"y":-16.59979366311384},"digits":[9],"last_update":647.277,"in_region":True},"6":{"id":6,"position":{"x":18.362044373363858,"y":-11.997332797164264},"digits":[4],"last_update":584.827,"in_region":True},"7":{"id":7,"position":{"x":19.248733438038954,"y":-10.806256651841338},"digits":[7],"last_update":587.161,"in_region":True},"8":{"id":8,"position":{"x":16.696829409930345,"y":-7.3170838568711165},"digits":[7],"last_update":586.28,"in_region":True},"9":{"id":9,"position":{"x":18.40552512194555,"y":-5.143790340649482},"digits":[9],"last_update":591.835,"in_region":True},"10":{"id":10,"position":{"x":17.597580391926904,"y":-3.06143142023166},"digits":[9],"last_update":601.85,"in_region":True},"11":{"id":11,"position":{"x":13.231197098590815,"y":-8.667802074389982},"digits":[9],"last_update":617.102,"in_region":True},"12":{"id":12,"position":{"x":14.137011204539624,"y":-9.910072661925632},"digits":[7],"last_update":616.444,"in_region":True}}

# 坐标、标签及颜色处理
x_coords = []   # 对应 x1 -> 竖直轴（向上为正）
y_coords = []   # 对应 -y1 -> 水平轴（向左为正）
labels = []
colors = []

for obj in respo.values():
    x1 = obj["position"]["x"]
    y1 = obj["position"]["y"]
    
    x_coords.append(x1)         # 竖直轴，x1 向上为正
    y_coords.append(-y1)        # 水平轴，-y1 向左为正
    labels.append("".join(str(d) for d in obj["digits"]))
    
    # 根据 in_region 判断颜色：True 为蓝色，False 为红色
    colors.append("blue" if obj["in_region"] else "red")

# 绘图
plt.figure(figsize=(8, 6))
plt.scatter(y_coords, x_coords, color=colors)

# 添加点的标签
for x, y, label in zip(y_coords, x_coords, labels):
    plt.text(x + 0.3, y + 0.3, label, fontsize=9)

# 绘制两条水平黑色虚线：x1=8.8 和 x1=4.8
plt.axhline(y=8.8, color='black', linestyle='--')
plt.axhline(y=4.8, color='black', linestyle='--')

# 设置坐标轴和样式
plt.axhline(0, color='gray', linestyle='--')
plt.axvline(0, color='gray', linestyle='--')
plt.xlabel("y")
plt.ylabel("x")
plt.title("Visiualization of Cube Position")
plt.grid(True)
plt.gca().set_aspect('equal', adjustable='box')
plt.show()
